(() => {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // localStorage can be blocked, so every access is wrapped.
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* ignore */ } },
  };

  const synth = window.speechSynthesis;
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const statusEl = $("#status");
  const video = $("#video");
  const canvas = $("#canvas");

  let lastMessage = "";
  let busy = false;
  let stream = null;
  let reminders = [];

  // ---------- speaking ----------
  function voiceEnabled() { return store.get("voice", "1") === "1" && !!synth; }

  function applyVoiceSetting() {
    // With the built-in voice off, a screen reader reads the status box instead.
    statusEl.setAttribute("aria-live", store.get("voice", "1") === "1" ? "off" : "polite");
  }

  function setStatus(text) { statusEl.textContent = text; }

  function speak(text) {
    lastMessage = text;
    setStatus(text);
    if (!voiceEnabled()) return Promise.resolve();
    synth.cancel();
    return new Promise((resolve) => {
      const u = new SpeechSynthesisUtterance(text);
      u.rate = Number(store.get("rate", "0.9")) || 0.9;
      u.lang = "en-IN";
      u.onend = resolve;
      u.onerror = resolve;
      synth.speak(u);
    });
  }

  function tone(freq, seconds) {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      const ctx = new Ctx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = freq;
      gain.gain.value = 0.2;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + seconds);
      osc.onended = () => ctx.close();
    } catch { /* no audio, ignore */ }
  }

  // ---------- camera ----------
  function cameraError(e) {
    if (e && e.name === "NotAllowedError") return "Camera permission was blocked. Please allow the camera and try again.";
    if (e && e.name === "NotFoundError") return "No camera was found.";
    return e && e.message ? e.message : "The camera is not working.";
  }

  async function ensureCamera() {
    if (stream) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error("The camera needs a secure page. On a phone, open the https address.");
    }
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: "environment" } },
      audio: false,
    });
    video.srcObject = stream;
    if (video.readyState < 2) await new Promise((r) => { video.onloadeddata = r; });
    await sleep(800); // let the camera adjust its exposure
  }

  function grabFrame() {
    const w = video.videoWidth, h = video.videoHeight;
    if (!w || !h) return Promise.reject(new Error("The camera is not ready yet."));
    const scale = Math.min(1, 640 / w);
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
    return new Promise((resolve, reject) =>
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Could not take a photo."))), "image/jpeg", 0.9));
  }

  async function postPhoto(url) {
    const blob = await grabFrame();
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "image/jpeg" }, body: blob });
    let data = {};
    try { data = await res.json(); } catch { /* not json */ }
    if (!res.ok) throw new Error(data.error || "The server could not read the photo.");
    return data;
  }

  // ---------- features ----------
  async function identifyNote() {
    if (busy) { await speak("Please wait, I am still working."); return; }
    busy = true;
    try {
      await speak("Hold the note flat in front of the camera.");
      try { await ensureCamera(); } catch (e) { await speak(cameraError(e)); return; }
      await sleep(2500);
      tone(880, 0.12); // photo taken
      const result = await postPhoto("/api/identify");
      await speak(result.message);
    } catch (e) {
      await speak("Sorry. " + (e.message || "Something went wrong."));
    } finally {
      busy = false;
    }
  }

  function tellTime() {
    return speak("The time is " + new Date().toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit", hour12: true }));
  }

  function tellDate() {
    return speak("Today is " + new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" }));
  }

  const NUMBER_WORDS = {
    a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8,
    nine: 9, ten: 10, fifteen: 15, twenty: 20, thirty: 30, forty: 40, half: 0.5,
  };
  const UNIT_SECONDS = { second: 1, minute: 60, min: 60, hour: 3600 };

  function parseDuration(text) {
    const words = Object.keys(NUMBER_WORDS).join("|");
    const m = text.match(new RegExp("\\b(\\d+(?:\\.\\d+)?|" + words + ")\\s*(?:an\\s+)?(second|minute|min|hour)s?\\b"));
    if (!m) return null;
    const n = /^\d/.test(m[1]) ? parseFloat(m[1]) : NUMBER_WORDS[m[1]];
    const unit = m[2] === "min" ? "minute" : m[2];
    const seconds = n * UNIT_SECONDS[unit];
    if (!(seconds > 0) || seconds > 86400) return null;
    return { n, unit, seconds };
  }

  function setReminder(text) {
    const d = parseDuration(text);
    if (!d) return speak("Please say it like: remind me in 5 minutes.");
    const t = text.match(/remind me (?:to|about) (.+?)\s+(?:in|after)\s/);
    const task = t ? t[1].replace(/\bmy\b/g, "your").replace(/\bme\b/g, "you") : "";
    const message = task ? "Reminder: " + task + "." : "Reminder! Your time is up.";
    const id = setTimeout(async () => {
      reminders = reminders.filter((x) => x !== id);
      tone(880, 0.3);
      await sleep(400);
      speak(message);
    }, d.seconds * 1000);
    reminders.push(id);
    return speak("Okay, I will remind you in " + describeDuration(d.seconds) + ".");
  }

  function describeDuration(seconds) {
    let n = seconds, unit = "second";
    if (seconds % 3600 === 0) { n = seconds / 3600; unit = "hour"; }
    else if (seconds % 60 === 0) { n = seconds / 60; unit = "minute"; }
    return n + " " + unit + (n === 1 ? "" : "s");
  }

  function cancelReminders() {
    const count = reminders.length;
    reminders.forEach(clearTimeout);
    reminders = [];
    return speak(count ? "All reminders are cancelled." : "You have no reminders.");
  }

  async function emergency() {
    const name = store.get("em_name", "");
    const num = store.get("em_num", "");
    if (!num) {
      await speak("No emergency contact is saved yet. Please open settings and add one.");
      return;
    }
    const spoken = num.replace(/\D/g, "").split("").join(" ");
    await speak(`Your emergency contact is ${name || "saved"}. The number is ${spoken}. Opening the phone dialer.`);
    window.location.href = "tel:" + num.replace(/[^\d+]/g, "");
  }

  function help() {
    return speak("You can say: what note is this, what time is it, what is the date, " +
      "remind me in 5 minutes, cancel reminders, emergency, repeat, or stop.");
  }

  // ---------- understanding commands ----------
  async function handle(raw) {
    const t = raw.toLowerCase().trim();
    if (!t) return;
    if (/\b(stop|quiet|silence)\b/.test(t)) { if (synth) synth.cancel(); setStatus("Stopped."); return; }
    if (/cancel.*remind|remind.*cancel/.test(t)) return cancelReminders();
    if (/\bremind/.test(t)) return setReminder(t);
    if (/\b(note|notes|money|currency|rupee|rupees)\b/.test(t)) return identifyNote();
    if (/\btime\b/.test(t)) return tellTime();
    if (/\b(date|day|today)\b/.test(t)) return tellDate();
    if (/\b(emergency|help me|call)\b/.test(t)) return emergency();
    if (/\brepeat\b|say that again/.test(t)) return speak(lastMessage || "I have nothing to repeat yet.");
    if (/\b(help|what can you do|commands)\b/.test(t)) return help();
    return speak("Sorry, I did not understand. Say help to hear what I can do.");
  }

  // ---------- listening ----------
  function listen() {
    return new Promise((resolve) => {
      const r = new Recognition();
      r.lang = "en-IN";
      r.interimResults = false;
      r.maxAlternatives = 1;
      let text = "", error = "";
      r.onresult = (e) => { text = e.results[0][0].transcript; };
      r.onerror = (e) => { error = e.error; };
      r.onend = () => resolve({ text, error });
      try { r.start(); } catch { resolve({ text: "", error: "start-failed" }); }
    });
  }

  async function voiceCommand() {
    if (synth) synth.cancel();
    if (!Recognition) {
      await speak("Voice input is not supported in this browser. Please use Chrome, or type a command.");
      return;
    }
    tone(660, 0.12);
    await sleep(200);
    setStatus("Listening…");
    const { text, error } = await listen();
    if (error === "not-allowed" || error === "service-not-allowed") {
      await speak("The microphone is blocked. Please allow the microphone and try again.");
    } else if (error === "audio-capture") {
      await speak("No microphone was found.");
    } else if (error === "network") {
      await speak("I cannot reach the speech service. Please check the internet.");
    } else if (!text) {
      await speak("I did not hear anything. Tap speak and try again.");
    } else {
      await handle(text);
    }
  }

  // ---------- calibration ----------
  async function refreshCalibration() {
    try {
      const res = await fetch("/api/calibration");
      const data = await res.json();
      $("#cal-status").textContent = "Calibrated: " + (data.calibrated.length ? data.calibrated.join(", ") + " rupee notes." : "none yet.");
    } catch { /* offline, ignore */ }
  }

  async function calibrateNote() {
    if (busy) return;
    busy = true;
    try {
      const note = $("#cal-note").value;
      await speak(`Hold the ${note} rupee note flat in front of the camera.`);
      try { await ensureCamera(); } catch (e) { await speak(cameraError(e)); return; }
      await sleep(2500);
      tone(880, 0.12);
      const data = await postPhoto("/api/calibrate?note=" + encodeURIComponent(note));
      await speak(data.message);
      refreshCalibration();
    } catch (e) {
      await speak("Sorry. " + (e.message || "Something went wrong."));
    } finally {
      busy = false;
    }
  }

  async function resetCalibration() {
    try {
      await fetch("/api/calibration", { method: "DELETE" });
      await speak("Calibration was reset.");
      refreshCalibration();
    } catch { await speak("Sorry, I could not reset it."); }
  }

  // ---------- wiring ----------
  function setupSettings() {
    $("#em-name").value = store.get("em_name", "");
    $("#em-num").value = store.get("em_num", "");
    $("#rate").value = store.get("rate", "0.9");
    $("#voice-on").checked = store.get("voice", "1") === "1";
    applyVoiceSetting();
    $("#save-settings").addEventListener("click", () => {
      store.set("em_name", $("#em-name").value.trim());
      store.set("em_num", $("#em-num").value.trim());
      store.set("rate", $("#rate").value);
      store.set("voice", $("#voice-on").checked ? "1" : "0");
      applyVoiceSetting();
      speak("Settings saved.");
    });
  }

  function start() {
    $("#intro").hidden = true;
    $("#app").hidden = false;
    $("#speak").focus();
    refreshCalibration();
    speak("Hello. Voice Helper is ready. Tap the big Speak button and say what note is this, what time is it, remind me, or emergency.");
  }

  function init() {
    setupSettings();
    const note = $("#support-note");
    if (!Recognition) {
      note.hidden = false;
      note.textContent = "Voice input needs Chrome or Safari. You can still use the buttons and typing.";
    }
    $("#start").addEventListener("click", start);
    $("#speak").addEventListener("click", voiceCommand);
    $("#btn-note").addEventListener("click", identifyNote);
    $("#btn-time").addEventListener("click", tellTime);
    $("#btn-date").addEventListener("click", tellDate);
    $("#btn-remind").addEventListener("click", () => setReminder("remind me in 5 minutes"));
    $("#btn-repeat").addEventListener("click", () => speak(lastMessage || "I have nothing to repeat yet."));
    $("#btn-emergency").addEventListener("click", emergency);
    $("#cal-btn").addEventListener("click", calibrateNote);
    $("#cal-reset").addEventListener("click", resetCalibration);
    $("#text-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const box = $("#text-cmd");
      const value = box.value;
      box.value = "";
      handle(value);
    });
    // Space bar anywhere on the page (outside inputs) = speak
    document.addEventListener("keydown", (e) => {
      if (e.code === "Space" && e.target === document.body && !$("#app").hidden) {
        e.preventDefault();
        voiceCommand();
      }
    });
  }

  init();
})();

"""Voice Helper: web app for visually impaired users.

Run on this computer:   python app.py
Then open:              http://127.0.0.1:5000

Use from a phone on the same Wi-Fi (the camera needs https on phones):
    python app.py --host 0.0.0.0 --https
Then open https://<this-computer's-ip>:5000 on the phone and accept the
certificate warning.
"""
import argparse

from flask import Flask, jsonify, render_template, request

import currency

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # photos only, 5 MB max


@app.get("/")
def index():
    return render_template("index.html", notes=list(currency.DEFAULTS))


@app.post("/api/identify")
def api_identify():
    try:
        return jsonify(currency.identify(request.get_data()))
    except ValueError as e:
        return jsonify(error=str(e)), 400


@app.post("/api/calibrate")
def api_calibrate():
    note = request.args.get("note", "")
    try:
        currency.calibrate(note, request.get_data())
    except ValueError as e:
        return jsonify(error=str(e)), 400
    return jsonify(ok=True, calibrated=currency.calibrated_notes(),
                   message=f"Saved the {note} rupee note.")


@app.get("/api/calibration")
def api_calibration():
    return jsonify(calibrated=currency.calibrated_notes())


@app.delete("/api/calibration")
def api_reset():
    currency.reset_calibration()
    return jsonify(ok=True, calibrated=[])


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5000)
    p.add_argument("--https", action="store_true",
                   help="serve with a self-signed certificate (needed for phone camera)")
    a = p.parse_args()
    app.run(host=a.host, port=a.port, ssl_context="adhoc" if a.https else None)

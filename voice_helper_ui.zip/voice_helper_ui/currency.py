"""Indian banknote identifier (prototype, colour based).

The browser sends a photo. We look at the centre of it, measure the typical
colour (HSV) and pick the closest note from a reference table.

DEFAULTS are rough guesses. Calibrating with your own notes and lighting
(Calibrate section in the app) gives much better results.
"""
import json
import os
import threading

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_FILE = os.path.join(BASE, "calibration.json")
_lock = threading.Lock()

# denomination -> [H, S, V] in OpenCV ranges (H 0-179, S 0-255, V 0-255)
DEFAULTS = {
    "10": [15, 150, 110],    # chocolate brown
    "20": [35, 120, 180],    # greenish yellow
    "50": [95, 150, 170],    # fluorescent blue
    "100": [130, 60, 170],   # lavender
    "200": [22, 200, 220],   # bright yellow
    "500": [20, 25, 140],    # stone grey
}


def _load_saved():
    try:
        with open(CAL_FILE) as f:
            data = json.load(f)
        return {k: v for k, v in data.items() if k in DEFAULTS}
    except (OSError, ValueError):
        return {}


def load_reference():
    """Defaults, overridden by whatever the user has calibrated."""
    ref = {k: list(v) for k, v in DEFAULTS.items()}
    ref.update(_load_saved())
    return ref


def calibrated_notes():
    return sorted(_load_saved(), key=int)


def image_hsv(data):
    """Median HSV colour of the centre area of a JPEG/PNG given as bytes."""
    frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if frame is None:
        raise ValueError("Could not read the photo")
    h, w = frame.shape[:2]
    centre = frame[h // 4: 3 * h // 4, w // 4: 3 * w // 4]
    hsv = cv2.cvtColor(centre, cv2.COLOR_BGR2HSV)
    return [float(np.median(hsv[:, :, i])) for i in range(3)]


def _distance(a, b):
    dh = abs(a[0] - b[0])
    dh = min(dh, 180 - dh) / 90.0          # hue is circular
    sat_weight = (a[1] + b[1]) / 510.0     # hue means little for grey notes
    ds = abs(a[1] - b[1]) / 255.0
    dv = abs(a[2] - b[2]) / 255.0
    return 2.0 * dh * sat_weight + ds + 0.5 * dv


def classify(hsv):
    """Return (denomination, confident). Confident is False on a close call."""
    ranked = sorted((_distance(hsv, v), k) for k, v in load_reference().items())
    best, second = ranked[0], ranked[1]
    confident = best[0] < 0.35 and (second[0] - best[0]) > 0.08
    return best[1], confident


def identify(data):
    """Returns {note, confident, message}; message is ready to be spoken."""
    hsv = image_hsv(data)
    if hsv[2] < 35:
        return {"note": None, "confident": False,
                "message": "It is too dark. Please move to a brighter place and try again."}
    note, confident = classify(hsv)
    if confident:
        msg = f"This looks like a {note} rupee note."
    else:
        msg = (f"I am not sure. It might be a {note} rupee note. "
               "Please hold the note flat in good light and try again.")
    return {"note": note, "confident": confident, "message": msg}


def calibrate(note, data):
    """Save the colour seen in this photo as the reference for `note`."""
    if note not in DEFAULTS:
        raise ValueError("Unknown note")
    hsv = image_hsv(data)
    if hsv[2] < 35:
        raise ValueError("The photo is too dark. Please try again in better light")
    with _lock:
        saved = _load_saved()
        saved[note] = hsv
        with open(CAL_FILE, "w") as f:
            json.dump(saved, f, indent=2)
    return hsv


def reset_calibration():
    with _lock:
        try:
            os.remove(CAL_FILE)
        except OSError:
            pass

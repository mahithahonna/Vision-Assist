# Voice Helper for the Blind (Community Project)

A web app that talks and listens. It identifies Indian banknotes with the camera,
tells the time and date, sets reminders and reads out an emergency contact.

Built with: Python (Flask + OpenCV) for the backend, HTML/CSS/JavaScript for the UI.
Voice in and out use the browser's built-in speech features.

## Setup
1. Install Python 3.9+
2. In this folder run: `pip install -r requirements.txt`

## Run on a laptop
```
python app.py
```
Open **http://127.0.0.1:5000** in **Chrome**, press *Start*, and allow the microphone and camera.

## Run on a phone (same Wi-Fi as the laptop)
Phones only allow the camera on secure (https) pages:
```
python app.py --host 0.0.0.0 --https
```
On the phone open `https://<laptop-ip>:5000` (find the IP with `ipconfig` / `ifconfig`),
and accept the certificate warning.

## First-time steps
1. Open **Settings** and save an emergency contact name and number.
2. Open **Calibrate notes** and take a photo of each note you have (good light, note flat).
3. Press **Speak** and say "what note is this".

## Voice commands
- "what note is this"
- "what time is it" / "what is the date"
- "remind me in 10 minutes" / "remind me to take medicine in 2 hours"
- "cancel reminders", "emergency", "repeat", "stop", "help"

You can also use the big buttons, type a command, or press the space bar to speak.

## Files
- `app.py`: Flask server and API
- `currency.py`: banknote colour matching and calibration
- `templates/index.html`: the page
- `static/style.css`: high-contrast, large-button design
- `static/app.js`: voice, camera, commands, reminders

## Accessibility notes
- Everything has audio feedback and a visible text version.
- Buttons are large with strong contrast and focus outlines.
- TalkBack/VoiceOver users: turn off "Use the built-in voice" in Settings so the screen reader reads the messages instead.

## Known limits (say these in your presentation)
- Note detection uses colour only. Lighting changes the result, so calibrate first.
- Voice recognition in Chrome needs internet (the browser sends audio to Google).
- Reminders only work while the page stays open.
- The emergency button opens the phone dialer; it does not place the call by itself.
- Older and newer series of a note differ in colour. Calibrate with the ones you use.
- Always double-check large amounts. Notes also have tactile marks.

## Ideas to improve
1. Replace colour matching with a trained image model (TensorFlow Lite or Teachable Machine, 50+ photos per note).
2. Add Hindi / Kannada voice commands.
3. Read text from photos (OCR) for medicine labels.
4. Test with visually impaired users and improve from their feedback.
